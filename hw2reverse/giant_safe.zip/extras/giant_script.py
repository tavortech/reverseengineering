import subprocess
import os

# Full path to the executable
EXECUTABLE_PATH = "./giant_safe.exe"

def test_giant_safe():
    """
    Test giant_safe.exe with different values of 'a' to find the correct solution.
    """
    
    # Check if the executable exists
    if not os.path.exists(EXECUTABLE_PATH):
        print(f"Error: Executable '{EXECUTABLE_PATH}' not found.")
        return False
    
    # Range of values to test for 'a'
    for a in range(200, 300):
    # for a in range(-10000, -9000):
    # for a in range(5000, 6000):
    # for a in range(2000, 3000):
    # for a in range(-3000, -2000):
    # for a in range(-1000, 1000):
        # Create input data
        input_data = f"""NULL
    80000000
    {a} -2147483648 -49
    E8CAFEFFFF
    """
        
        # Write input to temporary file
        temp_file = "input.txt"
        try:
            with open(temp_file, 'w') as f:
                f.write(input_data)
            
            # print(f"Testing with a = {a}")
            
            # Call the executable with input file
            with open(temp_file, 'r') as input_file:
                try:
                    result = subprocess.run(
                        [EXECUTABLE_PATH],
                        stdin=input_file,
                        capture_output=True,
                        text=True,
                        timeout=30  # 30 second timeout
                    )
                    
                    # Check if we got the success output
                    if "The encryption params are" in result.stdout or "The encryption params are" in result.stderr:
                        print(f"SUCCESS with a = {a}!")
                        print("Output:")
                        print(result.stdout)
                        
                        # Also print stderr if there's any
                        if result.stderr:
                        #     print("Error output:")
                            print(result.stderr)
                        
                        return True  # Success, stop testing
                    
                    # else:
                    #     print(f"No success with a = {a}")
                    #     if result.stdout:
                    #         print(f"stdout: {result.stdout[:200]}...")  # First 200 chars
                    #     if result.stderr:
                    #         print(f"stderr: {result.stderr[:200]}...")
                
                except subprocess.TimeoutExpired:
                    print(f"Timeout with a = {a}")
                except Exception as e:
                    print(f"Error with a = {a}: {e}")
        
        finally:
            # Clean up temporary file
            if os.path.exists(temp_file):
                os.remove(temp_file)
    
    print("No successful value found in the tested range.")
    return False

def test_single_value(a_value):
    """
    Test a single value of 'a' - useful for debugging specific cases.
    """
    input_data = f"""NULL
80000000
{a_value} -2147483648 -49
E8CAFEFFFF
"""
    
    temp_file = "input.txt"
    try:
        with open(temp_file, 'w') as f:
            f.write(input_data)
        
        # print(f"Testing single value a = {a_value}")
        
        # Check if the executable exists
        if not os.path.exists(EXECUTABLE_PATH):
            print(f"Error: Executable '{EXECUTABLE_PATH}' not found.")
            return False
        
        with open(temp_file, 'r') as input_file:
            result = subprocess.run(
                [EXECUTABLE_PATH],
                stdin=input_file,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            print("Return code:", result.returncode)
            print("STDOUT:")
            print(result.stdout)
            print("STDERR:")
            print(result.stderr)
            
            return "The encryption params are" in result.stdout or "The encryption params are" in result.stderr
    
    except Exception as e:
        print(f"Error: {e}")
        return False
    
    finally:
        if os.path.exists(temp_file):
            os.remove(temp_file)

if __name__ == "__main__":
    # Run the main test
    success = test_giant_safe()
    
    if not success:
        print("\nNo solution found. You might want to:")
        print("1. Expand the range of 'a' values")
        print("2. Check if giant_safe.exe is in the current directory")
        print("3. Verify the input format is correct")
    
